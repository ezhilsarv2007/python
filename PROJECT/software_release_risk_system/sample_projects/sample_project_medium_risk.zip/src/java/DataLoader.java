package com.example;

public class DataLoader {
    public void loadData() {
        try {
            int result = 100 / 2;
        } catch (Exception e) {
            // Empty catch block: swallowed exception
        }
    }
}
