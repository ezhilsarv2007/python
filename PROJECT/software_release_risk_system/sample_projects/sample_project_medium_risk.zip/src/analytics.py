import os
import sys
import math  # Unused import

def process_metrics(data_points):
    var_unused = 100  # Unused variable
    if not data_points:
        return 0
    return sum(data_points) / len(data_points)
