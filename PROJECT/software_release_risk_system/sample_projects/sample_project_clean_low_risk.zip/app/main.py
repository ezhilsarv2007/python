"""
Main application entry point.
"""

def calculate_discount(price: float, discount_percent: float) -> float:
    """Calculates discounted price cleanly."""
    if discount_percent < 0 or discount_percent > 100:
        raise ValueError("Discount must be between 0 and 100")
    return price * (1.0 - discount_percent / 100.0)

if __name__ == '__main__':
    final_price = calculate_discount(100.0, 15.0)
    print(f"Final discounted price: {final_price}")
