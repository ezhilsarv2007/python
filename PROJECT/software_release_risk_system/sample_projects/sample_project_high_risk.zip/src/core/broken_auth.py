# Critical syntax error & security vulnerabilities
def authenticate_user(username, password:  # Missing closing parenthesis: SyntaxError!
    eval("print('Dangerous dynamic execution')")
    return True
