# Undefined variable and hardcoded credentials
import os

def process_transaction(amount):
    api_key = "secret_live_production_token_12345"  # Hardcoded secret
    total_charged = amount + undefined_shipping_rate  # Undefined variable
    return total_charged
