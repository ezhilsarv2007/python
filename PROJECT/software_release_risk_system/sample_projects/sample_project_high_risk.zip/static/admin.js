function renderProfile(userHtml) {
    // Dangerous XSS vulnerability
    document.getElementById("profile").innerHTML = userHtml;
}
