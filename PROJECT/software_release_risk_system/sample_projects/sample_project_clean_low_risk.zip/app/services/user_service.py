"""
User management service.
"""

class UserService:
    def __init__(self):
        self.users = []

    def add_user(self, username: str) -> bool:
        if username not in self.users:
            self.users.append(username)
            return True
        return False

    def get_users_count(self) -> int:
        return len(self.users)
