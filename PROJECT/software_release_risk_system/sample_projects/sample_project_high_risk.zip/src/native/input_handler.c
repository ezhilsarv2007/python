#include <stdio.h>

void read_customer_input() {
    char user_buffer[32];
    // Critical buffer overflow vulnerability
    gets(user_buffer);
}
