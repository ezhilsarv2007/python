// Clean JavaScript client module
document.addEventListener('DOMContentLoaded', () => {
    const welcomeBox = document.getElementById('welcome-message');
    if (welcomeBox) {
        welcomeBox.textContent = 'Welcome to the clean release build!';
    }
});
