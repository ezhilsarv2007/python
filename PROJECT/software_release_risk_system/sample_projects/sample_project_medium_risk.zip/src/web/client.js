// Legacy var and debugger smell
var legacyUserToken = "user_session_abc";

function checkStatus() {
    debugger; // Leftover debugger statement
    console.log("Checking status...");
}
